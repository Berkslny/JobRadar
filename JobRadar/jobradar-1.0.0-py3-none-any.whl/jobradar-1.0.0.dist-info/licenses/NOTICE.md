# Kaynaklar ve teşekkür

JobRadar sıfırdan yazıldı; aşağıdaki projelerin fikirlerinden ve belgelerinden yararlanıldı.

| Proje | Lisans | Ne alındı |
|---|---|---|
| [career-ops](https://github.com/career-ops-hq/career-ops) | MIT | Arbeitsagentur v6, Rheinmetall, Softgarden, Personio, Workday ve SmartRecruiters uç noktaları ve sayfa yapıları; değerlendirme boyutları (CV uyumu, hedef uyumu, maaş, kültür, riskler), 4.0 başvuru eşiği, LinkedIn alarm e-postası içe aktarma, Connections.csv eşleştirme, temkinli "ilan kapandı mı" kontrolü fikri. Kod Python'a yeniden yazıldı. |
| [JobSpy](https://github.com/speedyapply/JobSpy) | MIT | Kütüphane olarak kullanılıyor (LinkedIn, Indeed, Glassdoor). |
| [JobNavigator](https://github.com/vesaias/JobNavigator) | MIT | Kaynaklar arası tekrar eleme ve URL kimliği fikirleri, iki aşamalı puanlama, Telegram bildirimleri ve kaynak sağlığı uyarıları. |
| [JobCtrl](https://github.com/ebarti/JobCtrl) | AGPL-3.0 | Sadece fikir: her CV maddesinin profildeki bir gerçeğe bağlanması ve uydurma içeren taslağın reddedilmesi, onaysız başvuru gönderilmemesi. Koddan hiçbir şey alınmadı. |
| [bundesAPI/jobsuche-api](https://github.com/bundesAPI/jobsuche-api) | Belge | Jobsuche API parametreleri ve jobdetails uç noktası. |
| [freehire.me API](https://freehire.me/jobs-api) | Kullanım şartları | Kişisel, ticari olmayan kullanımda anahtarsız okuma. |
